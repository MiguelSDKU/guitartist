import "./footer.css";

function Footer() {
  return (
    <div className="footer">
      <p>Online Store by Me</p>
    </div>
  );
}

export default Footer;
