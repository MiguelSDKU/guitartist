import "./navbar.css";

function Navbar() {
  return (
    <div>
      <h4>Menu will be here</h4>
    </div>
  );
}

export default Navbar;
