import "./cart.css";

function Cart() {
  return <div>Hello cart</div>;
}

export default Cart;
