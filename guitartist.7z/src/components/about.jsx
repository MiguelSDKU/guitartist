import "./about.css";

function About() {
  return (
    <div>
      <div className="abt-card">
        <div className="outer-sqr">
          {" "}
          <div className="inner-sqr">
            {" "}
            <h1>Created by</h1>
            <h2>Miguel Cota</h2>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
