export const catalog = [
  {
    title: "test1",
    image: "/images/No_Image_Available.jpg",
    price: 12.33,
    category: "Fruit",
    _id: "12351",
  },
  {
    title: "test1",
    image: "/images/No_Image_Available.jpg",
    price: 12.33,
    category: "Fruit",
    _id: "12351",
  },
  {
    title: "test1",
    image: "/images/No_Image_Available.jpg",
    price: 12.33,
    category: "Fruit",
    _id: "12351",
  },
];
